<?php
include("header2.php");
?>
        <!-- Top Bar End -->

        <!-- Nav Bar Start -->
     
        <!-- Nav Bar End -->
        

        <!-- Service Start -->
        <div class="service mt-125">
            <div class="container">
                <div class="section-header">
                  
                    <h2>Files Security</h2>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="service-item">
                            <img src="img/icon-4.png" alt="Icon">
                            <h3>Upload Files</h3>
                         
                            <a href="file.php">Upload Files</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="service-item">
                            <img src="img/icon-4.png" alt="Icon">
                            <h3>Download Files</h3>
                           
                            <a href="getfile.php">Download Files</a>
                        </div>
                    </div>
                   

                </div>
            </div>
        </div>
        <!-- Service End -->


        


        <!-- Footer Start -->
       
<?php
include("footer.php");

?>