<?php

include("header.php");
?>


        <!-- Top Bar End -->

        <!-- Nav Bar Start -->
       
        <!-- Nav Bar End -->
        

        <!-- About Start -->
        <div class="about mt-125">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="about-img">
                            <div class="about-img-1">
                                <img src="img/about-2.jpg" alt="Image">
                            </div>
                            <div class="about-img-2">
                                <img src="img/about-1.jpg" alt="Image">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="section-header">
                            
                            <h2>Learn About Us</h2>
                        </div>
                        <div class="about-text">
                            <p>
                            Visual cryptography is a cryptographic technique which allows visual information (pictures, text, etc.) to be encrypted in such a way that decryption can be done just by sight reading. Visual cryptography, degree associated rising cryptography technology, uses the characteristics of human vision to rewrite encrypted photos. Visual cryptography provides secured digital transmission that is used just for merely the once.                      </p>
                            <p>
                            Numerous guidance like military maps and business identifications are transmitted over the internet. Whereas pattern secret photos, security problems ought to be compelled to be taken into thought as a result of hackers may utilize weak link over the communication network to steal info that they need.To touch upon the protection problems with secret photos, varied image secret sharing schemes are developed. anyone will use it for coding with none science information and any computations.                        </p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->


        


        


        
<?php
include("footer.php");

?>