<?php
error_reporting(0);
$con=mysqli_connect("localhost","root","","gec_crypto") or die("error");
date_default_timezone_set("Asia/Calcutta");
?>